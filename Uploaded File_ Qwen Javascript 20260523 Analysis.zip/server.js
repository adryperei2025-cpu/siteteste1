require("dotenv").config();
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const axios = require("axios");
const WebSocket = require("ws");
const path = require("path");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*", methods: ["GET", "POST"] } });

app.use(cors());
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// ⚙️ Configurações de Arbitragem
const MIN_SPREAD = 0.005;   // 0.5% mínimo
const EST_FEES = 0.004;     // 0.4% estimado (maker + taker)
const SYNC_LIMIT = 2000;    // Máx diferença de timestamp (ms)
const EMIT_MS = 1000;       // Emitir para clientes a cada 1s

let opportunities = [];
const books = {}; // { exchangeName: { pair: { bids, asks, ts, latency, status, ws } } }

// Lista de pares de moedas a serem monitorados (exemplo de 50 dos 150 solicitados)
// Para expandir para 150 pares, adicione mais entradas a esta lista.
const PAIRS = [
  'BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'SOL/USDT', 'XRP/USDT',
  'ADA/USDT', 'DOGE/USDT', 'AVAX/USDT', 'DOT/USDT', 'LINK/USDT',
  'MATIC/USDT', 'LTC/USDT', 'SHIB/USDT', 'TRX/USDT', 'BCH/USDT',
  'NEAR/USDT', 'UNI/USDT', 'ICP/USDT', 'ETC/USDT', 'XLM/USDT',
  'ATOM/USDT', 'FIL/USDT', 'APT/USDT', 'HBAR/USDT', 'VET/USDT',
  'OP/USDT', 'ARB/USDT', 'GRT/USDT', 'APE/USDT', 'AXS/USDT',
  'SAND/USDT', 'MANA/USDT', 'EGLD/USDT', 'THETA/USDT', 'EOS/USDT',
  'AAVE/USDT', 'COMP/USDT', 'MKR/USDT', 'SNX/USDT', 'ZRX/USDT',
  'KNC/USDT', 'CRV/USDT', 'BAT/USDT', 'CHZ/USDT', 'ENJ/USDT',
  'GALA/USDT', 'FTM/USDT', 'ONE/USDT', 'FLOW/USDT', 'XTZ/USDT',
  // Adicione mais 100 pares aqui para atingir o total de 150
  // Ex: 'ALGO/USDT', 'QNT/USDT', 'AXS/USDT', 'FTT/USDT', 'WAVES/USDT', 'XMR/USDT', 'ZEC/USDT', 'DASH/USDT', 'NEO/USDT', 'QTUM/USDT',
  // 'ONT/USDT', 'IOST/USDT', 'VET/USDT', 'ICX/USDT', 'OMG/USDT', 'ZIL/USDT', 'KSM/USDT', 'DOT/USDT', 'EOS/USDT', 'TRX/USDT',
  // 'XLM/USDT', 'ADA/USDT', 'LINK/USDT', 'BCH/USDT', 'LTC/USDT', 'XRP/USDT', 'ETH/USDT', 'BTC/USDT', ...
];

// 🔗 Conectores de Exchange (Binance, OKX, Bybit, Kraken, KuCoin como exemplos)
// Para adicionar mais corretoras (até 70), seria necessário pesquisar a documentação de cada uma
// e implementar as funções 'sub' e 'parse' específicas para seus formatos de WebSocket.
// Cada corretora tem uma implementação de WebSocket única, o que exige adaptação manual.
const EXCHANGES_CONFIG = [
  {
    name: 'Binance',
    wsUrl: 'wss://stream.binance.com:9443/ws',
    restUrl: 'https://api.binance.com/api/v3/ping',
    // Binance usa um stream por par, então a URL do WS será construída dinamicamente
    // Ex: wss://stream.binance.com:9443/ws/btcusdt@depth20@100ms
    parse: (d, pair) => {
      const symbol = pair.replace('/', '').toLowerCase();
      if (d.s && d.s.toLowerCase() === symbol && d.bids?.[0] && d.asks?.[0]) {
        return { bids: [[+d.bids[0][0], +d.bids[0][1]]], asks: [[+d.asks[0][0], +d.asks[0][1]]] };
      }
      return null;
    }
  },
  {
    name: 'OKX',
    wsUrl: 'wss://ws.okx.com:8443/ws/v5/public',
    restUrl: 'https://www.okx.com/api/v5/system/status',
    // OKX permite múltiplas subscrições em uma única conexão
    sub: (pair) => JSON.stringify({ op: 'subscribe', args: [{ channel: 'books', instId: pair.replace('/', '-') }] }),
    parse: (d, pair) => {
      const instId = pair.replace('/', '-');
      if (d.arg?.channel === 'books' && d.data?.[0] && d.data[0].instId === instId) {
        return { bids: [[+d.data[0].bids[0][0], +d.data[0].bids[0][1]]], asks: [[+d.data[0].asks[0][0], +d.data[0].asks[0][1]]] };
      }
      return null;
    }
  },
  {
    name: 'Bybit',
    wsUrl: 'wss://stream.bybit.com/v5/public/spot',
    restUrl: 'https://api.bybit.com/v5/market/time',
    // Bybit permite múltiplas subscrições em uma única conexão
    sub: (pair) => JSON.stringify({ op: 'subscribe', args: [`orderbook.1.${pair.replace('/', '')}`] }),
    parse: (d, pair) => {
      const symbol = pair.replace('/', '');
      if (d.topic && d.topic.includes(`orderbook.1.${symbol}`) && d.data?.s === symbol) {
        return { bids: [[+d.data.b[0][0], +d.data.b[0][1]]], asks: [[+d.data.a[0][0], +d.data.a[0][1]]] };
      }
      return null;
    }
  },
  {
    name: 'Kraken',
    wsUrl: 'wss://ws.kraken.com/',
    restUrl: 'https://api.kraken.com/0/public/Time',
    sub: (pair) => JSON.stringify({ event: 'subscribe', pair: [pair.replace('/', '/')], subscription: { name: 'book', depth: 10 } }),
    parse: (d, pair) => {
      // Kraken envia arrays, o primeiro elemento é o channelID, o segundo é o book, o terceiro é o channelName, o quarto é o pair
      if (Array.isArray(d) && d.length >= 4 && d[2] === 'book-10' && d[3] === pair.replace('/', '/')) {
        const bookData = d[1];
        if (bookData.as && bookData.bs) {
          return { bids: [[+bookData.bs[0][0], +bookData.bs[0][1]]], asks: [[+bookData.as[0][0], +bookData.as[0][1]]] };
        }
      }
      return null;
    }
  },
  {
    name: 'KuCoin',
    wsUrl: 'wss://ws-api.kucoin.com/v2/websocket',
    restUrl: 'https://api.kucoin.com/api/v1/timestamp',
    sub: (pair) => JSON.stringify({
      id: Date.now(),
      type: 'subscribe',
      topic: `/market/level2Depth5:${pair.replace('/', '-')}`,
      privateChannel: false,
      response: true
    }),
    parse: (d, pair) => {
      if (d.type === 'message' && d.topic && d.topic.includes(`/market/level2Depth5:${pair.replace('/', '-')}`)) {
        const data = d.data;
        if (data.bids && data.asks) {
          return { bids: [[+data.bids[0][0], +data.bids[0][1]]], asks: [[+data.asks[0][0], +data.asks[0][1]]] };
        }
      }
      return null;
    }
  }
  // Para adicionar mais corretoras (até 70), seria necessário pesquisar a documentação de cada uma
  // e implementar as funções 'sub' e 'parse' específicas para seus formatos de WebSocket.
  // A lista de 150 pares também precisaria ser expandida aqui.
];

// Inicializar estrutura de books
EXCHANGES_CONFIG.forEach(ex => {
  books[ex.name] = {};
  PAIRS.forEach(pair => {
    books[ex.name][pair] = { bids: [], asks: [], ts: 0, latency: null, status: 'disconnected' };
  });
});

// 📡 Inicializar WebSockets
EXCHANGES_CONFIG.forEach(ex => {
  const connect = () => {
    const ws = new WebSocket(ex.wsUrl);
    
    ws.on('open', () => {
      console.log(`✅ ${ex.name} WS conectado`);
      // Para exchanges que usam uma única conexão para múltiplos pares (OKX, Bybit, Kraken, KuCoin)
      if (ex.sub) {
        PAIRS.forEach(pair => {
          books[ex.name][pair].status = 'connected';
          books[ex.name][pair].ws = ws; // Armazena a conexão WS para cada par
          ws.send(ex.sub(pair));
        });
      } else if (ex.name === 'Binance') {
        // Para Binance, que usa streams separados por par
        PAIRS.forEach(pair => {
          const binanceWs = new WebSocket(`${ex.wsUrl}/${pair.replace('/', '').toLowerCase()}@depth20@100ms`);
          books[ex.name][pair].status = 'connected';
          books[ex.name][pair].ws = binanceWs;

          binanceWs.on('open', () => console.log(`✅ Binance ${pair} WS conectado`));
          binanceWs.on('message', raw => {
            try {
              const parsed = ex.parse(JSON.parse(raw), pair);
              if (parsed) {
                books[ex.name][pair] = { ...parsed, ts: Date.now(), latency: books[ex.name][pair].latency, status: 'connected', ws: binanceWs };
                calculateArb();
              }
            } catch (e) { /* console.error(`Erro no parse da Binance para ${pair}:`, e); */ }
          });
          binanceWs.on('close', () => { books[ex.name][pair].status = 'disconnected'; setTimeout(() => connectBinancePair(ex, pair), 5000); });
          binanceWs.on('error', () => { books[ex.name][pair].status = 'error'; });
        });
      }
    });

    ws.on('message', raw => {
      try {
        const data = JSON.parse(raw);
        PAIRS.forEach(pair => {
          const parsed = ex.parse(data, pair);
          if (parsed) {
            books[ex.name][pair] = { ...parsed, ts: Date.now(), latency: books[ex.name][pair].latency, status: 'connected', ws };
            calculateArb();
          }
        });
      } catch (e) { /* console.error(`Erro no parse da ${ex.name}:`, e); */ }
    });

    ws.on('close', () => {
      PAIRS.forEach(pair => books[ex.name][pair].status = 'disconnected');
      setTimeout(connect, 5000);
    });
    ws.on('error', () => {
      PAIRS.forEach(pair => books[ex.name][pair].status = 'error');
    });
  };

  // Função auxiliar para reconectar pares da Binance individualmente
  const connectBinancePair = (ex, pair) => {
    const binanceWs = new WebSocket(`${ex.wsUrl}/${pair.replace('/', '').toLowerCase()}@depth20@100ms`);
    books[ex.name][pair].ws = binanceWs;
    binanceWs.on('open', () => console.log(`✅ Binance ${pair} WS reconectado`));
    binanceWs.on('message', raw => {
      try {
        const parsed = ex.parse(JSON.parse(raw), pair);
        if (parsed) {
          books[ex.name][pair] = { ...parsed, ts: Date.now(), latency: books[ex.name][pair].latency, status: 'connected', ws: binanceWs };
          calculateArb();
        }
      } catch (e) { /* console.error(`Erro no parse da Binance para ${pair}:`, e); */ }
    });
    binanceWs.on('close', () => { books[ex.name][pair].status = 'disconnected'; setTimeout(() => connectBinancePair(ex, pair), 5000); });
    binanceWs.on('error', () => { books[ex.name][pair].status = 'error'; });
  };

  // Inicia a conexão principal para exchanges que suportam múltiplos pares em uma única WS
  if (ex.sub) {
    connect();
  } else if (ex.name === 'Binance') {
    // Para Binance, inicia conexões individuais para cada par
    PAIRS.forEach(pair => connectBinancePair(ex, pair));
  }

  // Ping de latência a cada 10s
  setInterval(async () => {
    try {
      const start = Date.now();
      await axios.head(ex.restUrl, { timeout: 3000 });
      PAIRS.forEach(pair => books[ex.name][pair].latency = Date.now() - start);
    } catch (e) {
      PAIRS.forEach(pair => books[ex.name][pair].latency = null);
    }
  }, 10000);
});

// 📊 Calculadora Cross-Exchange
function calculateArb() {
  const newOpportunities = [];

  PAIRS.forEach(pair => {
    const activeBooksForPair = Object.entries(books)
      .filter(([, exBooks]) => exBooks[pair] && exBooks[pair].status === 'connected' && exBooks[pair].bids[0]?.[0] && exBooks[pair].asks[0]?.[0])
      .map(([exName, exBooks]) => ({ name: exName, book: exBooks[pair] }));

    if (activeBooksForPair.length < 2) return;

    for (let i = 0; i < activeBooksForPair.length; i++) {
      for (let j = 0; j < activeBooksForPair.length; j++) {
        if (i === j) continue;

        const buyEx = activeBooksForPair[i].name;
        const buyBook = activeBooksForPair[i].book;
        const sellEx = activeBooksForPair[j].name;
        const sellBook = activeBooksForPair[j].book;

        if (Math.abs(buyBook.ts - sellBook.ts) > SYNC_LIMIT) continue;

        const buyPrice = buyBook.asks[0][0];
        const sellPrice = sellBook.bids[0][0];
        const spread = (sellPrice - buyPrice) / buyPrice;

        if (spread < MIN_SPREAD) continue;

        const net = spread - EST_FEES;
        if (net < 0.001) continue; // mínimo 0.1% líquido

        newOpportunities.push({
          pair: pair,
          buyEx: buyEx, sellEx: sellEx,
          buyPrice: +buyPrice.toFixed(2), sellPrice: +sellPrice.toFixed(2),
          spread: +(spread * 100).toFixed(3),
          net: +(net * 100).toFixed(3),
          liquidity: +((buyBook.asks[0][1] + sellBook.bids[0][1]) * buyPrice).toFixed(2),
          syncDelta: Math.abs(buyBook.ts - sellBook.ts),
          ts: Date.now()
        });
      }
    }
  });
  opportunities = newOpportunities.sort((a, b) => b.net - a.net);
}

// 📤 Emitir para frontend
setInterval(() => io.emit('opportunities', opportunities), EMIT_MS);

// 🌐 Rotas
app.get('/api/opportunities', (req, res) => res.json({ success: true, data: opportunities, count: opportunities.length, timestamp: new Date().toISOString() }));
app.get('/api/health', (req, res) => {
  const status = {};
  EXCHANGES_CONFIG.forEach(ex => {
    status[ex.name] = {};
    PAIRS.forEach(pair => {
      status[ex.name][pair] = { status: books[ex.name][pair].status, latency: books[ex.name][pair].latency };
    });
  });
  res.json({ ok: true, uptime: process.uptime(), exchanges: status, timestamp: new Date().toISOString() });
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// 🔌 Socket.io
io.on('connection', socket => {
  console.log('🔗 Cliente:', socket.id);
  socket.emit('opportunities', opportunities);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => console.log(`🚀 Backend rodando em http://localhost:${PORT}`));

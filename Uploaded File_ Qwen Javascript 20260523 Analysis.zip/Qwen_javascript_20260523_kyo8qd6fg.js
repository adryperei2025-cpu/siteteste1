require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const axios = require('axios');
const WebSocket = require('ws');
const path = require('path');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*", methods: ["GET", "POST"] } });

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ⚙️ Configurações de Arbitragem
const MIN_SPREAD = 0.005;   // 0.5% mínimo
const EST_FEES = 0.004;     // 0.4% estimado (maker + taker)
const SYNC_LIMIT = 2000;    // Máx diferença de timestamp (ms)
const EMIT_MS = 1000;       // Emitir para clientes a cada 1s

let opportunities = [];
const books = {}; // { exchangeName: { bids, asks, ts, latency, status, ws } }

// 🔗 Conectores de Exchange (Binance + OKX)
const exchanges = [
  {
    name: 'Binance',
    wsUrl: 'wss://stream.binance.com:9443/ws/btcusdt@depth20@100ms',
    restUrl: 'https://api.binance.com/api/v3/ping',
    parse: d => d.bids?.[0] && d.asks?.[0] ? { bids: [[+d.bids[0][0], +d.bids[0][1]]], asks: [[+d.asks[0][0], +d.asks[0][1]]] } : null
  },
  {
    name: 'OKX',
    wsUrl: 'wss://ws.okx.com:8443/ws/v5/public',
    restUrl: 'https://www.okx.com/api/v5/system/status',
    sub: JSON.stringify({ op: 'subscribe', args: [{ channel: 'books', instId: 'BTC-USDT' }] }),
    parse: d => d.arg?.channel === 'books' && d.data?.[0] ? { bids: [[+d.data[0].bids[0][0], +d.data[0].bids[0][1]]], asks: [[+d.data[0].asks[0][0], +d.data[0].asks[0][1]]] } : null
  }
];

// 📡 Inicializar WebSockets
exchanges.forEach(ex => {
  books[ex.name] = { bids: [], asks: [], ts: 0, latency: null, status: 'connecting' };

  const connect = () => {
    const ws = new WebSocket(ex.wsUrl);
    books[ex.name].ws = ws;

    ws.on('open', () => {
      books[ex.name].status = 'connected';
      if (ex.sub) ws.send(ex.sub);
      console.log(`✅ ${ex.name} WS conectado`);
    });

    ws.on('message', raw => {
      try {
        const parsed = ex.parse(JSON.parse(raw));
        if (parsed) {
          books[ex.name] = { ...parsed, ts: Date.now(), latency: books[ex.name].latency, status: 'connected', ws };
          calculateArb();
        }
      } catch {}
    });

    ws.on('close', () => { books[ex.name].status = 'disconnected'; setTimeout(connect, 5000); });
    ws.on('error', () => { books[ex.name].status = 'error'; });
  };
  connect();

  // Ping de latência a cada 10s
  setInterval(async () => {
    const start = Date.now();
    try { await axios.head(ex.restUrl, { timeout: 3000 }); books[ex.name].latency = Date.now() - start; }
    catch { books[ex.name].latency = null; }
  }, 10000);
});

// 📊 Calculadora Cross-Exchange
function calculateArb() {
  const active = Object.entries(books).filter(([, b]) => b.status === 'connected' && b.bids[0]?.[0] && b.asks[0]?.[0]);
  if (active.length < 2) return;

  const opps = [];
  for (let i = 0; i < active.length; i++) {
    for (let j = 0; j < active.length; j++) {
      if (i === j) continue;
      const [buyName, buy] = active[i];
      const [sellName, sell] = active[j];

      if (Math.abs(buy.ts - sell.ts) > SYNC_LIMIT) continue;

      const buyPrice = buy.asks[0][0];
      const sellPrice = sell.bids[0][0];
      const spread = (sellPrice - buyPrice) / buyPrice;
      if (spread < MIN_SPREAD) continue;

      const net = spread - EST_FEES;
      if (net < 0.001) continue; // mínimo 0.1% líquido

      opps.push({
        pair: 'BTC/USDT',
        buyEx: buyName, sellEx: sellName,
        buyPrice: +buyPrice.toFixed(2), sellPrice: +sellPrice.toFixed(2),
        spread: +(spread * 100).toFixed(3),
        net: +(net * 100).toFixed(3),
        liquidity: +((buy.asks[0][1] + sell.bids[0][1]) * buyPrice).toFixed(2),
        syncDelta: Math.abs(buy.ts - sell.ts),
        ts: Date.now()
      });
    }
  }
  opportunities = opps.sort((a, b) => b.net - a.net);
}

// 📤 Emitir para frontend
setInterval(() => io.emit('opportunities', opportunities), EMIT_MS);

// 🌐 Rotas
app.get('/api/opportunities', (req, res) => res.json({ success: true, data: opportunities, count: opportunities.length, timestamp: new Date().toISOString() }));
app.get('/api/health', (req, res) => {
  const status = Object.entries(books).map(([n, b]) => ({ name: n, status: b.status, latency: b.latency }));
  res.json({ ok: true, uptime: process.uptime(), exchanges: status, timestamp: new Date().toISOString() });
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// 🔌 Socket.io
io.on('connection', socket => {
  console.log('🔗 Cliente:', socket.id);
  socket.emit('opportunities', opportunities);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => console.log(`🚀 Backend rodando em http://localhost:${PORT}`));